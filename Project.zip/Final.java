import java.util.*;
class Final extends Prison
{
	public static void main(String args[])
	{
		File f=new File();
		Scanner sc=new Scanner(System.in)
	}
}