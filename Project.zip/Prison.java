class Prison extends File
{
	int building[][];
	Prison()
	{
		building = new int[4][5]
	}
	public static void main(String args[])
	{
		File f=new File();
	}
}